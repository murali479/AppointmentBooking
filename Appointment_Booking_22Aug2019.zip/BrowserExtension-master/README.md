# BrowserExtension

Auto fill form data for registration

# Usage

Clone the project to a local repository.

Open chrome and enable developer options in the browser extesion.

Click on load unpacked button and refresh the loaded extension.

Start filling the form data in popup.........
