// window.open("https://service2.diplo.de/rktermin/extern/choose_realmList.do?locationCode=banga&request_locale=en");
window.open("https://service2.diplo.de/rktermin/extern/appointment_showMonth.do?locationCode=banga&realmId=210&categoryId=337");
// window.open("https://www.google.com");